def function_package():
    print("I am in function_package() in package_1/module_1.py")